﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01.GenericBoxofString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<int> values = new List<int>();

            for (int i = 0; i < n; i++)
            {
                int value = int.Parse(Console.ReadLine());
                values.Add(value);

                //Box<int> box = new Box<int>(value);
                //Console.WriteLine(box);
            }
            Box<int> box = new Box<int>(values);

            int[] indexesToSwap = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            box.SwapElementsByIndex(values, indexesToSwap[0], indexesToSwap[1]);
            Console.WriteLine(box);
        }
    }
}
