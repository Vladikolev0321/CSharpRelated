﻿using System;

namespace Stealer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();
            //string[] requestedFields = { "username", "password" };
            //string result = spy.StealFieldInfo("Stealer.Hacker", requestedFields);
            //Console.WriteLine(result);
            string result = spy.AnalyzeAcessModifiers("Stealer.Hacker");
            Console.WriteLine(result);
        }
    }
}
