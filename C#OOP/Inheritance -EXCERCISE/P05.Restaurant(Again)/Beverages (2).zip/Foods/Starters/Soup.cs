﻿using P05.Restaurant_Again_.Foods.Starter;
using System;
using System.Collections.Generic;
using System.Text;

namespace P05.Restaurant_Again_.Foods.Starter
{
    public class Soup : Starter
    {
        public Soup(string name, decimal price, double grams) 
            : base(name, price, grams)
        {
        }
    }
}
