﻿using System;

namespace P05.Restaurant_Again_
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
