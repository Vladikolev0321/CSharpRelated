﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.NeedForSpeed.Car
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
}
