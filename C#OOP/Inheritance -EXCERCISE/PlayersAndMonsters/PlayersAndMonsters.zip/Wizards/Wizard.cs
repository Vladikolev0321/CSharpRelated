﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Wizards
{
    public class Wizard : Hero
    {
        public Wizard(string username, int level) 
            : base(username, level)
        {
        }
    }
}
