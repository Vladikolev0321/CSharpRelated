﻿using PlayersAndMonsters.Wizards;
using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //SoulMaster sm = new SoulMaster("asda", 300);
            //DarkWizard da = new DarkWizard("Gosho", 20);
            //Console.WriteLine(da.ToString());
            //Console.WriteLine(sm.ToString());
        }
    }
}