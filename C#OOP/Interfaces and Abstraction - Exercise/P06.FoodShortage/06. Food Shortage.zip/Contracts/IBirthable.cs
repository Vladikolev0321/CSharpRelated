﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06.FoodShortage
{
    public interface IBirthable
    {
        string GetBirth();
    }
}
