﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06.FoodShortage
{
    interface IIdentifiable
    {       

        string GetId();
    }
}
