﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.BirthdayCelebrations.Contracts
{
    public interface IBirthable
    {
        string GetBirth();
    }
}
