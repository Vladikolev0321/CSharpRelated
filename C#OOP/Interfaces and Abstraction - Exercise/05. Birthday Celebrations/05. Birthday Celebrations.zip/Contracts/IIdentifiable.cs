﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.BirthdayCelebrations
{
    interface IIdentifiable
    {
        string GetId();
    }
}
