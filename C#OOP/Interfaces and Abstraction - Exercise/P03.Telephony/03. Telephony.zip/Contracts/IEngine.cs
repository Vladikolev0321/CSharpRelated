﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Telephony.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
