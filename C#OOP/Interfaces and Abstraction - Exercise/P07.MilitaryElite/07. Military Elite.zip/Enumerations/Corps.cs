﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07.MilitaryElite.Enumerations
{
    public enum  Corps
    {
        Airforces = 1,
        Marines = 2,
    }
}
