﻿using P04._BorderControl.Core;
using System;
using System.Text;

namespace P04.BorderControl
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
