﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04._BorderControl.Contracts
{
    interface IIdentifiable
    {
        string GetId();
    }
}
