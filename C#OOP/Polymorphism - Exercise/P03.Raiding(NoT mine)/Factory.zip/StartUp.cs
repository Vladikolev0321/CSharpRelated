﻿
namespace _3._Raiding
{
    using Core;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
