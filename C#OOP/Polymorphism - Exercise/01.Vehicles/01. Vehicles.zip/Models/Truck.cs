﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace P01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double FUEL_CONS_INCREMENT = 1.6;
        private const double REFUEL_EFIICIENCY_PERCENTSGE = 0.95;
        public Truck(double fuelquantity, double fuelconsumption)
            : base(fuelquantity, fuelconsumption)
        {
        }

        public override double FuelConsumption
        {
            get
            {
                return base.FuelConsumption;
            }
            protected set
            {
                base.FuelConsumption = value + FUEL_CONS_INCREMENT;
            }

        }

        public override void Refuel(double liters)
        {
            base.Refuel(liters 
                * REFUEL_EFIICIENCY_PERCENTSGE);
        }
    }
}
