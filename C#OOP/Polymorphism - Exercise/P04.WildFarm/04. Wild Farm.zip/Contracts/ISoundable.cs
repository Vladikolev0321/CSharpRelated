﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Contracts
{
    public interface ISoundable
    {
        void ProduceSound();
    }
}
