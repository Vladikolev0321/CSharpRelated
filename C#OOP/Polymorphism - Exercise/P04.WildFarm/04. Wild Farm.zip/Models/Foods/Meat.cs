﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}
