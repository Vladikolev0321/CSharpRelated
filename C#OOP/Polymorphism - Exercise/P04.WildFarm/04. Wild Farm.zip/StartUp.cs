﻿using P04.WildFarm.Core;
using System;

namespace P04.WildFarm
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
